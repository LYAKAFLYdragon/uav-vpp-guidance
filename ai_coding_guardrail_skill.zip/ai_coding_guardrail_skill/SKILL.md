# AI 编程助手防错护栏 Skill

## 目标

本 skill 用于在科研代码开发中约束 AI 编程助手，避免其生成“看似能跑、测试通过，但实际方法逻辑错误”的代码。它特别适合以下项目形态：

- 学位论文或科研工程；
- 多模块闭环系统；
- 强依赖配置文件与实验脚本；
- 需要可复现结果与可解释消融；
- 用户本人编程基础有限、需要依赖 AI 编程助手推进代码。

本 skill 的核心思想是：

> 先固定方法主线和接口契约，再允许 AI 编程助手写代码；先审计语义正确性，再相信测试结果。

---

## 何时使用

当用户准备让 AI 编程助手执行以下任务时，应先调用本 skill：

1. 新增训练脚本、评估脚本、绘图脚本；
2. 修改环境、策略网络、预测器、控制器、奖励函数或终止条件；
3. 接入新算法模块；
4. 扩展实验配置；
5. 重构已有项目；
6. 审计 AI 编程助手刚刚生成的代码；
7. 检查“pytest 全过”是否真的代表方法正确。

---

## 总体工作流

每轮 AI 编程开发必须拆成以下 6 步：

1. **任务边界声明**
   - 本阶段做什么；
   - 本阶段不做什么；
   - 不允许修改哪些文件或目录；
   - 不允许破坏哪些既有 baseline。

2. **方法主线复述**
   - 要求 AI 编程助手先用文字复述当前方法链路；
   - 如果复述错误，不允许进入写代码阶段。

3. **接口契约锁定**
   - 明确输入、输出、单位、shape、范围、fallback 行为；
   - 明确模块职责边界。

4. **最小实现**
   - 只实现当前阶段必要功能；
   - 不允许顺手加入额外模型、额外优化器或额外重构。

5. **分层测试**
   - 单元测试；
   - 接口测试；
   - 行为测试；
   - smoke 运行；
   - 输出文件检查。

6. **独立审计**
   - 使用审计提示词检查语义正确性；
   - P0/P1 问题修复前，不允许进入下一阶段。

---

## 严格等级定义

### P0：必须立刻修复

满足任一条件即为 P0：

- 代码无法运行；
- 训练或评估结果完全不可信；
- 核心接口语义错误；
- 单位或范围错配；
- baseline 被破坏；
- 数据泄漏；
- 使用伪造指标或假数据；
- 关闭模块仍被调用；
- 实验输出污染根目录；
- 旧项目或外部 reference 被误修改。

### P1：进入下一阶段前修复

- 日志不完整；
- 配置 key 不一致；
- 输出路径不规范；
- 缺少关键 fallback；
- 测试覆盖不足；
- 文档与命令不一致。

### P2：后续优化

- 性能较差但逻辑正确；
- 控制器粗糙但可诊断；
- 可视化不够美观；
- 参数未调优；
- 代码结构可以进一步抽象。

### P3：风格问题

- 注释语言不统一；
- 命名可读性一般；
- 文档排版问题。

---

## 核心不变量模板

每次要求 AI 编程助手修改代码前，必须列出并检查核心不变量。示例：

```text
核心不变量：

1. policy action 必须是 shape=(3,) 的归一化动作，范围 [-1, 1]。
2. VirtualPointGenerator 是唯一负责把 action 映射到物理虚拟点偏移的模块。
3. trajectory predictor 只输出 predicted_target_position，不直接输出控制指令。
4. VirtualPointGenerator 不允许内部创建或调用 predictor。
5. trajectory_prediction.enabled=false 时 predictor_adapter 必须为 None。
6. anchor_mode=current_target 时不得读取 predicted_target_position。
7. anchor_mode=predicted_target 时必须优先使用 predicted_target_position。
8. 预测失败必须 fallback 到 current_target。
9. 所有实验输出必须在 outputs/。
10. SimplePointMass 用于机制验证，JSBSim 用于高保真验证。
11. 不允许为了让测试通过而删除或弱化关键断言。
12. 不允许用 NaN、0 或假数据伪造指标。
```

---

## AI 编程助手任务提示词框架

向 AI 编程助手下达开发任务时，应使用以下结构：

```text
你现在继续开发项目：
<项目路径>

本阶段名称：
<Stage 名称>

本阶段目标：
<一句话目标>

本阶段必须做：
1. ...
2. ...

本阶段绝对不要做：
1. ...
2. ...

核心不变量：
1. ...
2. ...

允许新增文件：
1. ...

允许修改文件：
1. ...

禁止修改：
1. ...

配置要求：
<列出关键 YAML key、单位、范围>

接口要求：
<列出输入、输出、shape、单位、fallback>

输出要求：
<所有输出路径必须在 outputs/>

测试要求：
<单元测试、接口测试、行为测试、smoke>

验收命令：
<pytest 和 smoke 命令>

验收汇报格式：
<新增文件、修改文件、pytest、输出路径、风险>
```

---

## 审计提示词框架

当 AI 编程助手完成代码后，应使用以下审计提示词：

```text
你现在作为代码审计助手，对刚完成的阶段做严格检查。

要求：
1. 本轮以检查为主，不要继续开发新功能。
2. 不要只相信验收汇报，要实际检查代码、配置、测试、输出路径。
3. 如果发现 P0/P1 问题，必须明确指出。
4. 除非发现明确 bug，否则不要大规模重构。

请检查：

一、方法主线是否被破坏
二、核心不变量是否仍成立
三、配置 key、单位、shape、范围是否一致
四、关闭模块是否真的未被调用
五、fallback 是否真实存在
六、评估脚本是否按 scenario/method/backend 隔离输出
七、测试是否只测运行，还是也测语义
八、日志和指标是否可解释
九、所有输出是否在 outputs/
十、pytest 与 smoke 是否通过

最后按 P0/P1/P2/P3 给出问题清单。
P0/P1 修复前，不允许进入下一阶段。
```

---

## 分层测试要求

### 1. 单元测试

测试单个模块是否数学或逻辑正确。

示例：

- CV predictor 在匀速目标上预测正确；
- CA predictor 在匀加速目标上预测正确；
- action scaling 不越界；
- reward 对优势态势给正反馈；
- termination 能识别 success / timeout / OOB。

### 2. 接口测试

测试模块之间是否接对。

示例：

- disabled 模块不被创建；
- enabled 模块正常创建；
- predicted_target 模式真正使用 predicted_target_position；
- fallback 到 current_target；
- info 字段包含必要诊断信息。

### 3. 行为测试

测试闭环行为是否符合直觉。

示例：

- favorable 场景中 range 不应快速发散到极大值；
- 匀速目标下 CV prediction_error 应较小；
- high-G 场景下 CV/CA prediction_error 应变大；
- 虚拟点偏移不应出现百万米级异常；
- smoke 训练可以失败，但不能 NaN、不能 crash、不能写错路径。

---

## 代码审查重点

### 配置文件

必须检查：

- enabled 开关；
- anchor_mode；
- action_low/action_high；
- backend；
- total_timesteps；
- output_dir；
- scenario 列表；
- horizon_steps、dt、history_length；
- reward 和 termination 阈值。

### 环境总入口

重点检查：

- reset；
- step；
- predictor_adapter；
- VirtualPointGenerator；
- LOSRateGuidance；
- RewardCalculator；
- TerminationChecker；
- info 字段。

### 策略或专家系统

重点检查：

- 输出是否是归一化动作；
- shape 是否正确；
- 是否绕过 VPP/LOS 直接控制后端；
- deterministic / stochastic 行为是否清楚。

### 预测器

重点检查：

- 是否只预测目标位置；
- 是否包含 fallback；
- 是否处理 NaN/inf；
- 是否记录 prediction_valid 和 fallback_reason。

### 评估脚本

重点检查：

- 是否 method/scenario/backend 分组；
- 是否保存 metrics 和 trajectories；
- 是否没有用假值填充指标；
- 是否缺字段时优雅降级。

---

## 禁止事项

AI 编程助手不得：

1. 为了让测试通过而删除关键断言；
2. 关闭失败测试而不说明原因；
3. 在未要求时重构大面积代码；
4. 把多个新模型一次性全部接入；
5. 绕过现有主数据流；
6. 把实验输出写到根目录；
7. 修改旧项目或 legacy reference；
8. 用固定成功率、固定指标或随机假数据冒充实验结果；
9. 将 NaN 静默替换成 0 后不记录；
10. 把 smoke 结果解释成充分训练结论。

---

## 验收汇报模板

每轮开发后，要求 AI 编程助手按以下格式汇报：

```text
1. 新增了哪些文件
2. 修改了哪些文件
3. 本阶段完成了哪些功能
4. 本阶段明确没有做什么
5. 如何运行
6. 输出文件在哪里
7. pytest 结果
8. smoke 结果
9. 是否确认旧项目未被修改
10. 是否确认所有输出在 outputs/
11. 是否确认核心不变量仍成立
12. 是否发现 P0/P1/P2/P3 问题
13. 当前结果是否足以支持进入下一阶段
14. 下一步建议
```

---

## 对科研项目的特别提醒

- smoke 通过只代表链路通，不代表算法有效；
- 测试全过只代表当前测试覆盖范围内没发现问题；
- 图能画出来不代表指标有解释力；
- 训练曲线存在不代表策略学到了有效行为；
- 单一平均值不够，必须按场景分组；
- 神经网络模型不能宣称普遍最优，必须做 scenario-wise stress testing；
- 任何预测增强方法都必须同时报告 prediction_error 和闭环 performance。
