# UAV-VPP-Guidance 项目接口契约示例

本文件是针对 `E:\uav-vpp-guidance` 项目的示例契约，可在每轮提示词中引用。

## 主数据流

```text
obs
  ↓
policy πθ 或 ExpertVPPPolicy
  ↓
normalized Δp in [-1, 1]
  ↓
VirtualPointGenerator
  ↓
virtual point
  ↓
LOSRateGuidance
  ↓
Nz_cmd / roll_rate_cmd / throttle_cmd
  ↓
SimplePointMassEnv or JSBSimEnv
  ↓
reward / termination / info
```

## 预测增强数据流

```text
target history
  ↓
TrajectoryPredictorAdapter
  ↓
predicted_target_position
  ↓
VirtualPointGenerator
```

## 禁止破坏的约束

1. PPO action 不是米单位，而是 [-1, 1] 归一化动作。
2. predictor 不直接控制飞机。
3. VPP generator 不直接创建 predictor。
4. enabled=false 时 predictor_adapter 必须为 None。
5. 所有实验输出必须在 outputs/。
6. SimplePointMass 结果不能直接宣称为六自由度物理可信结论。
7. smoke 训练不能作为最终性能结论。
