# 审计提示词模板

你现在作为代码审计助手，对当前阶段做严格核查。

要求：

1. 本轮以检查、审计、验证为主，不要继续推进新功能。
2. 不要只相信验收汇报，要实际检查代码、配置、测试、输出路径和命令。
3. 如果发现 P0/P1 问题，请停止推进并优先修复。
4. 除非发现明确 bug，否则不要大规模重构。

## 请检查以下内容

### 一、方法主线

当前代码是否仍符合主线：

```text
obs → policy/expert → normalized action → VPP → LOS guidance → backend → reward/done
```

### 二、核心不变量

1. policy/expert action 是否仍为 [-1, 1]；
2. VPP 是否仍是唯一 action-to-offset 映射模块；
3. predictor 是否只输出 predicted_target_position；
4. disabled predictor 是否真的不创建、不调用；
5. fallback 是否真实存在；
6. 输出是否全部在 outputs/。

### 三、配置一致性

检查 YAML key 是否与代码读取一致，单位、shape、范围是否一致。

### 四、接口一致性

检查 simple/jsbsim 后端、training/evaluation/plotting 是否使用统一字段。

### 五、测试质量

判断测试是否只覆盖“能运行”，还是覆盖了语义正确性。

### 六、实际命令

运行或验证：

```bash
pytest tests/ -v
<smoke commands>
<evaluation commands>
<plot commands>
```

## 审计结论格式

1. 总体结论
2. 已通过项目
3. 发现的问题
   - P0
   - P1
   - P2
   - P3
4. 如有修改，列出修改文件和原因
5. 验证结果
6. 风险判断
7. 下一步建议
