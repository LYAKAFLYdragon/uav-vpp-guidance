# 核心不变量检查清单

每轮开发或审计都应检查以下内容。

## 动作与虚拟点

- [ ] policy/expert 输出 shape=(3,)
- [ ] action 范围是 [-1, 1]
- [ ] action 不是物理米单位
- [ ] VirtualPointGenerator 负责 action 到物理偏移的映射
- [ ] 虚拟点偏移没有百万米级异常

## 预测器

- [ ] trajectory_prediction.enabled=false 时 predictor_adapter=None
- [ ] trajectory_prediction.enabled=true 时 predictor_adapter 正常创建
- [ ] predictor 只输出 predicted_target_position
- [ ] predictor 不直接输出控制指令
- [ ] predictor 失败时 fallback 到 current_target
- [ ] info 中记录 prediction_valid 和 fallback_reason

## 环境与控制

- [ ] reset/step 返回符合约定
- [ ] info 字段完整
- [ ] simple/jsbsim 后端接口基本一致
- [ ] NaN/inf 有保护
- [ ] 控制饱和有记录

## 训练与评估

- [ ] episode 日志不丢失
- [ ] update 日志和 episode 日志区分清楚
- [ ] metrics 按 method/scenario/backend 分组
- [ ] trajectories 保存到 outputs/
- [ ] smoke 结果不被解释为最终性能

## 项目安全

- [ ] 旧项目未被修改
- [ ] 根目录无实验输出
- [ ] 没有删除关键测试
- [ ] 没有用假值填充指标
